function Regu = Regu_1(~,~)

Regu = 1;