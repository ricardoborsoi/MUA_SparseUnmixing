function Regu = Regu_regsize(R,~)

Regu = 1/sum(R(:));